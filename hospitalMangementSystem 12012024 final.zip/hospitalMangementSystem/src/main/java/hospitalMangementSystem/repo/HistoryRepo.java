
package hospitalMangementSystem.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import hospitalMangementSystem.Entity.History;

public interface HistoryRepo extends JpaRepository<History, Long>{

}
