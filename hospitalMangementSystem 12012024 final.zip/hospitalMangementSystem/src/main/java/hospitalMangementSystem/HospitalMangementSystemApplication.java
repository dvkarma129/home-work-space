package hospitalMangementSystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HospitalMangementSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(HospitalMangementSystemApplication.class, args);
	}

}
