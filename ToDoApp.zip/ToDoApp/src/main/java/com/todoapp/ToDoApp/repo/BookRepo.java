package com.todoapp.ToDoApp.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.todoapp.ToDoApp.dto.BookDto;
import com.todoapp.ToDoApp.dto.TaskDto;
import com.todoapp.ToDoApp.dto.UserDto;

@Repository
public interface BookRepo extends JpaRepository<BookDto, Integer>{

}
