package com.todoapp.ToDoApp.service;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;

import javax.transaction.Transactional;

import org.apache.catalina.User;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.todoapp.ToDoApp.dto.TaskDto;
import com.todoapp.ToDoApp.dto.UserDto;
import com.todoapp.ToDoApp.repo.TaskListRepo;
import com.todoapp.ToDoApp.repo.UserRepo;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class ToDoService {
	private final EmailService emailService;
	private final TaskListRepo tRepo;
	private final UserRepo uRepo;
	int bonusPoints;

	@Transactional
	public void getRegister(UserDto model) throws IOException {
		UserDto udto = new UserDto();
		udto.setUserName(model.getUserName());
		udto.setUserContact(model.getUserContact());
		udto.setProImgPath(getProImgPath(model.getProImg()));
		udto.setUserGmail(model.getUserGmail());
		udto.setUserPassword(model.getUserPassword());
		uRepo.save(udto);

		emailService.sendMail(udto);
	}

	private String getProImgPath(MultipartFile proImg) throws IOException {
		String path = "../image/";

		if (!proImg.isEmpty()) {
			Timestamp timestamp = new Timestamp(System.currentTimeMillis());
			try {

				String fileName = "profileImg" + timestamp.getTime() + ".jpg";
				path = path + fileName;
				File file = new File(
						"C:\\Users\\Admin\\Documents\\workspace-spring-tool-suite-4-4.18.1.RELEASE\\ToDoApp\\src\\main\\webapp\\image\\"
								+ fileName);
				Files.copy(proImg.getInputStream(), file.toPath());

			} catch (Exception e) {
				e.printStackTrace();
			}
		} else {
			path = path + "defaultProPic.jpg";
		}

		return path;
	}

	public boolean userLogin(UserDto model) {
		int count = uRepo.countByUserGmailAndUserPassword(model.getUserGmail(), model.getUserPassword());
		if (count > 0) {
			return true;
		}
		return false;
	}

	public UserDto getUserData(UserDto model) {
		UserDto udto = uRepo.findByUserGmailAndUserPassword(model.getUserGmail(), model.getUserPassword());
		System.out.println("USER DATA --> " + udto);
		return udto;
	}

	public void addNewTodo(TaskDto model, int userId) {
		TaskDto tdto = new TaskDto();
		tdto.setTopic(model.getTopic());
		tdto.setDescription(model.getDescription());
		tdto.setStatus("New");
		tdto.setCompletedDate(model.getCompletedDate());
		tdto.setUserId(userId);
		tRepo.save(tdto);
	}

	public void editTodo(TaskDto model, int userId, int myPoints) {
		TaskDto tdto = tRepo.getById(model.getTaskId());
		tdto.setTopic(model.getTopic());
		tdto.setDescription(model.getDescription());
		tdto.setStatus(model.getStatus());
		tdto.setUserId(userId);
		tRepo.save(tdto);

		if (model.getStatus().equals("Complete")) {
			if (tdto.getCompletedOnDate().before(tdto.getCompletedDate())) {
				bonusPoints = 5;
				myPoints = myPoints + bonusPoints;
				UserDto udto = uRepo.getByUserId(userId);
				udto.setMyPoints(myPoints);
				uRepo.save(udto);
			} else if (tdto.getCompletedOnDate().equals(tdto.getCompletedDate())) {
				bonusPoints = 3;
				myPoints = myPoints + bonusPoints;
				UserDto udto = uRepo.getByUserId(userId);
				udto.setMyPoints(myPoints);
				uRepo.save(udto);
			} else if (tdto.getCompletedOnDate().after(tdto.getCompletedDate())) {
				bonusPoints = 1;
				myPoints = myPoints + bonusPoints;
				UserDto udto = uRepo.getByUserId(userId);
				udto.setMyPoints(myPoints);
				uRepo.save(udto);
			} else {
				bonusPoints = 0;
				myPoints = myPoints + bonusPoints;
				UserDto udto = uRepo.getByUserId(userId);
				udto.setMyPoints(myPoints);
				uRepo.save(udto);
			}

		} else if (model.getStatus().equals("Incomplete")) {
			bonusPoints = 0;
			myPoints = myPoints + bonusPoints;
			UserDto udto = uRepo.getByUserId(userId);
			udto.setMyPoints(myPoints);
			uRepo.save(udto);
		} else {
			bonusPoints = 0;
			myPoints = myPoints + bonusPoints;
			UserDto udto = uRepo.getByUserId(userId);
			udto.setMyPoints(myPoints);
			uRepo.save(udto);
		}
	}

	public void setNewPassword(UserDto model, String UserGmail) {
		UserDto udto = uRepo.getByUserGmail(UserGmail);
		udto.setUserPassword(model.getUserPassword());
		uRepo.save(udto);

		System.out.println(" udto ----> " + udto);
	}

	public void getUpdateProfile(UserDto model, int userId) throws IOException {
		UserDto udto = uRepo.getByUserId(userId);
		udto.setUserName(model.getUserName());
		udto.setUserContact(model.getUserContact());
		udto.setProImgPath(getProImgPath(model.getProImg()));
		udto.setUserGmail(model.getUserGmail());
		uRepo.save(udto);
	}

}
