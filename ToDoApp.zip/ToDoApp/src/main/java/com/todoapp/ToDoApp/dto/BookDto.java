package com.todoapp.ToDoApp.dto;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "BookDto")
@Getter
@Setter
@ToString
@JsonIgnoreProperties({"hibernateLazyInitializer","handler"})
public class BookDto {

	@Id
	@GeneratedValue
	private int bookId;
	
	@Column(name="BOOK_NAME")
	private String bookName;
	
	@Column(name="BOOK_AUTHORE")
	private String author;
	
	@Column(name="BOOK_PRICE")
	private int price;

	@Column(name="BOOK_Cost")
	private int cost;

	
}
