package com.todoapp.ToDoApp.control;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.todoapp.ToDoApp.dto.BookDto;
import com.todoapp.ToDoApp.dto.TaskDto;
import com.todoapp.ToDoApp.dto.UserDto;
import com.todoapp.ToDoApp.repo.BookRepo;
import com.todoapp.ToDoApp.repo.TaskListRepo;
import com.todoapp.ToDoApp.repo.UserRepo;
import com.todoapp.ToDoApp.service.EmailService;
import com.todoapp.ToDoApp.service.ToDoService;
import com.todoapp.ToDoApp.service.WorkboookGenerator;

import lombok.RequiredArgsConstructor;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;

@RequiredArgsConstructor
@Controller
@RequestMapping("/todo")
public class ToDoCtrl {

	String userName = " ";
	String userGmail = " ";
	String userContact;
	int userId = 0;
	int myPoints = 0;
	String userUsername = " ";
	String userPassword = " ";
	String proImgPath = " ";
	int otp;

	private final EmailService emailService;
	private final WorkboookGenerator warkGen;
	private final TaskListRepo tRepo;
	private final UserRepo uRepo;
	private final BookRepo bRepo;
	private final ToDoService tService;
	boolean validUser = false;
	boolean validEmail;
	boolean validOtp;

	@GetMapping("/getRegister")
	public String getRegister() {
		return "register";
	}

	@PostMapping("/register")
	public String getRegister(@ModelAttribute UserDto model) throws IOException {
		tService.getRegister(model);
		return "login";
	}

	@GetMapping("/getLogin")
	public String getLogin() {
		return "login";
	}

	@PostMapping("/login")
	public ModelAndView getLogin(@ModelAttribute UserDto model) {
		validUser = tService.userLogin(model);
		UserDto udto = new UserDto();
		if (validUser) {
			udto = tService.getUserData(model);

			userId = udto.getUserId();
			userName = udto.getUserName();
			userContact = udto.getUserContact();
			userGmail = udto.getUserGmail();
			userPassword = udto.getUserPassword();
			myPoints = udto.getMyPoints();

			ArrayList<Object> list = new ArrayList<Object>();

			ArrayList<TaskDto> tdto = tRepo.findAllByUserId(userId);
			System.out.println(tdto);

			udto = uRepo.getByUserId(userId);
			System.out.println(udto);

			list.add(tdto);// array {tdto,udto}0,1,2,3,4,
			list.add(udto);

			otp = emailService.sendOtp(udto, userId);
//			return new ModelAndView("home", "t", list);
			return new ModelAndView("otpVerifiaction", "u", list);
//			return new ModelAndView("home", "t", tdto);
		}
		return new ModelAndView("userNotFound", "u", udto);
	}

	@GetMapping("/getHome")
	public ModelAndView getHome(@ModelAttribute UserDto model) {

		ArrayList<Object> list = new ArrayList<Object>();
		System.out.println("------->>>>>>>" + userId);
		ArrayList<TaskDto> tdto = tRepo.findAllByUserId(userId);
		System.out.println("==========>>>>>" + tdto);

		UserDto udto = uRepo.getByUserId(userId);
		System.out.println("..........>>>>" + udto);

		list.add(tdto);
		list.add(udto);

		return new ModelAndView("home", "t", list);
	}

	@PostMapping("/otpVerification")
	public ModelAndView otpVerification(@ModelAttribute UserDto model) {
		UserDto udto = uRepo.getByUserId(userId);
		if (udto.getUserOtp() == model.getUserOtp()) {
			ArrayList<Object> list = new ArrayList<Object>();
			System.out.println("------->>>>>>>" + userId);
			ArrayList<TaskDto> tdto = tRepo.findAllByUserId(userId);
			System.out.println("==========>>>>>" + tdto);
			list.add(tdto);
			list.add(udto);
			return new ModelAndView("home", "t", list);
		}
		return new ModelAndView("userNotFound", "u", udto);
	}

	@GetMapping("/myTask")
	public ModelAndView mytask(@ModelAttribute UserDto model) {

		ArrayList<Object> list = new ArrayList<Object>();
		System.out.println("------->>>>>>>" + userId);
		ArrayList<TaskDto> tdto = tRepo.findAllByUserId(userId);
		System.out.println("==========>>>>>" + tdto);

		UserDto udto = uRepo.getByUserId(userId);
		System.out.println("..........>>>>" + udto);

		list.add(tdto);
		list.add(udto);
		return new ModelAndView("myTasks", "t", list);
	}

	@GetMapping("/getForgotPassword")
	public String getForgotPassword() {
		return "forgotPassword";
	}

	@PostMapping("forgotPassword")
	public String forgotPassword(@RequestParam String UserGmail) {
		System.out.println("userGmail ----> " + UserGmail);
		userGmail = UserGmail;
		int count = uRepo.countByUserGmail(UserGmail);
		if (count > 0 && count < 2) {
			return "changePassword";
		}
		return "userNotFound";
	}

	@PostMapping("/setNewPassword")
	public String setNewPassword(@ModelAttribute UserDto model) {
		tService.setNewPassword(model, userGmail);
		return "login";
	}

	@GetMapping("/getTodo")
	public ModelAndView getTodo(@ModelAttribute TaskDto model) {
		List<TaskDto> tdto = tRepo.findAllByUserId(userId);
		System.out.println(tdto);
		return new ModelAndView("tasks", "t", tdto);
	}

	@GetMapping("/addNewTodo")
	public String addNewTodo() {
		return "NewTask";
	}

	@PostMapping("/addTodo")
	public ModelAndView addTodo(@ModelAttribute TaskDto model) {
		System.out.println("model.getCompletedDate() ---> " + model.getCompletedDate());
		tService.addNewTodo(model, userId);
		ArrayList<Object> list = new ArrayList<Object>();
		System.out.println("------->>>>>>>" + userId);
		ArrayList<TaskDto> tdto = tRepo.findAllByUserId(userId);
		System.out.println("==========>>>>>" + tdto);

		UserDto udto = uRepo.getByUserId(userId);
		System.out.println("..........>>>>" + udto);

		list.add(tdto);
		list.add(udto);

		return new ModelAndView("home", "t", list);
	}

	@GetMapping("/editTodo")
	public ModelAndView editTodo(@RequestParam int TaskId) {
		TaskDto tdto = tRepo.getById(TaskId);
		System.out.println("tdto --------------------> " + tdto.toString());
		return new ModelAndView("updateTodo", "t", tdto);
	}

	@PostMapping("/edit")
	public ModelAndView editTodo(@ModelAttribute TaskDto model) {
		tService.editTodo(model, userId, myPoints);
		ArrayList<Object> list = new ArrayList<Object>();
		System.out.println("------->>>>>>>" + userId);
		ArrayList<TaskDto> tdto = tRepo.findAllByUserId(userId);
		System.out.println("==========>>>>>" + tdto);

		UserDto udto = uRepo.getByUserId(userId);
		System.out.println("..........>>>>" + udto);

		list.add(tdto);
		list.add(udto);

		return new ModelAndView("home", "t", list);
	}

	@PostMapping("/editt")
	public ModelAndView editTodoo(@ModelAttribute TaskDto model) {
		tService.editTodo(model, userId, myPoints);
		ArrayList<Object> list = new ArrayList<Object>();
		System.out.println("------->>>>>>>" + userId);
		ArrayList<TaskDto> tdto = tRepo.findAllByUserId(userId);
		System.out.println("==========>>>>>" + tdto);

		UserDto udto = uRepo.getByUserId(userId);
		System.out.println("..........>>>>" + udto);

		list.add(tdto);
		list.add(udto);

		return new ModelAndView("home", "t", list);
	}

	@GetMapping("/deleteTodo")
	public ModelAndView deleteTodo(@RequestParam int TaskId) {
		tRepo.deleteById(TaskId);
		ArrayList<Object> list = new ArrayList<Object>();
		System.out.println("------->>>>>>>" + userId);
		ArrayList<TaskDto> tdto = tRepo.findAllByUserId(userId);
		System.out.println("==========>>>>>" + tdto);

		UserDto udto = uRepo.getByUserId(userId);
		System.out.println("..........>>>>" + udto);

		list.add(tdto);
		list.add(udto);

		return new ModelAndView("home", "t", list);
	}

	@GetMapping("/deleteTodoo")
	public ModelAndView deleteTodoo(@RequestParam int TaskId) {
		tRepo.deleteById(TaskId);
		ArrayList<Object> list = new ArrayList<Object>();
		System.out.println("------->>>>>>>" + userId);
		ArrayList<TaskDto> tdto = tRepo.findAllByUserId(userId);
		System.out.println("==========>>>>>" + tdto);

		UserDto udto = uRepo.getByUserId(userId);
		System.out.println("..........>>>>" + udto);

		list.add(tdto);
		list.add(udto);

		return new ModelAndView("home", "t", list);
	}

	// excel sheet generate
	@GetMapping("/generateWorkbook")
	public ModelAndView generateWorkbook(@ModelAttribute TaskDto model) throws IOException {
		// warkGen.generateWorkbook();
		warkGen.downloadData(userId);
		List<TaskDto> tdto = tRepo.findAllByUserId(userId);
		return new ModelAndView("home", "t", tdto);
	}

	@GetMapping("/insertWorkbook")
	public ModelAndView insertWorkbook(@ModelAttribute TaskDto model) throws IOException {
		// warkGen.generateWorkbook();
		warkGen.insertWorkbook();
		List<TaskDto> tdto = tRepo.findAllByUserId(userId);
		return new ModelAndView("home", "t", tdto);
	}

	@GetMapping("/insertFile")
	public String insertFile() {
		// warkGen.generateWorkbook();
		return "insertFile";
	}

	@PostMapping("/insertFile")
	public ModelAndView insertFile(@ModelAttribute TaskDto model, @RequestParam MultipartFile file) throws IOException { //
		warkGen.insertFile(file, userId);
		List<TaskDto> tdto = tRepo.findAllByUserId(userId);
		return new ModelAndView("home", "t", tdto);
	}

	@GetMapping("/getPointShop")
	public ModelAndView getPointShop(@ModelAttribute BookDto model) {
		List<BookDto> bdto = bRepo.findAll();
		return new ModelAndView("shop", "b", bdto);

	}

	@GetMapping("/getProfile")
	public ModelAndView getProfile(@ModelAttribute UserDto model) {
		UserDto udto;
		if (validUser) {
			udto = uRepo.getById(userId);
			userId = udto.getUserId();
			userName = udto.getUserName();
			userContact = udto.getUserContact();
			userGmail = udto.getUserGmail();
			userPassword = udto.getUserPassword();
			myPoints = udto.getMyPoints();

			System.out.println("profile dto ---->" + udto);
			return new ModelAndView("profile", "u", udto);
		}
		return new ModelAndView("userNotFound");
	}

	@GetMapping("/updateProfile")
	public ModelAndView updateProfile(@ModelAttribute UserDto model) {
		UserDto udto;
		if (validUser) {
			udto = uRepo.getById(userId);
			System.out.println("update profile dto ---->" + udto);
			return new ModelAndView("updateProfile", "u", udto);
		}
		return new ModelAndView("userNotFound");
	}

	@PostMapping("/updateProfile")
	public ModelAndView updateProfileData(@ModelAttribute UserDto model) throws IOException {
		UserDto udto = uRepo.getById(userId);
		tService.getUpdateProfile(model, userId);
		return new ModelAndView("profile", "u", udto);
	}
	
	@GetMapping("/byid")
	public String getById() {
		return "byid";
	}

	@PostMapping("/getById")
	public ModelAndView getById(@ModelAttribute UserDto model) {
		UserDto dto = uRepo.getByUserId(model.getUserId());
		System.out.println(dto);
		return new ModelAndView("getById", "u", dto);
	}

	@GetMapping("/genPdf")
	public ResponseEntity<byte []> genPdf() throws Exception, JRException {
		List<TaskDto> todoList = tRepo.findAllByUserId(userId);
		JRBeanCollectionDataSource jrBean = new JRBeanCollectionDataSource(todoList);
		JasperReport  compReport = JasperCompileManager.compileReport(new FileInputStream("src/main/resources/JpdfTrial1.jrxml"));
		  HashMap<String, Object> map = new HashMap<>();
		JasperPrint report =  JasperFillManager.fillReport(compReport, map,jrBean);
//		JasperExportManager.exportReportToPdfFile(report, "JpdfTrial1.pdf");
		
		byte [] data = JasperExportManager.exportReportToPdf(report);
		
		HttpHeaders headers = new HttpHeaders();
		headers.set(HttpHeaders.CONTENT_DISPOSITION, "inline;filename=notes.pdf");
		
		//		return "pdf generatee999999999999999999999";
	
		return ResponseEntity.ok().headers(headers).contentType(MediaType.APPLICATION_PDF).body(data);
	}
	
	@GetMapping("/genPdfById")
	public ResponseEntity<byte []> genPdfById(@RequestParam int TaskId) throws Exception, JRException {
		TaskDto todoList = tRepo.getById(TaskId);
		JRBeanCollectionDataSource jrBean = new JRBeanCollectionDataSource(Collections.singletonList(todoList));
		JasperReport  compReport = JasperCompileManager.compileReport(new FileInputStream("src/main/resources/JpdfTrial1.jrxml"));
		  HashMap<String, Object> map = new HashMap<>();
		JasperPrint report =  JasperFillManager.fillReport(compReport, map,jrBean);
//		JasperExportManager.exportReportToPdfFile(report, "JpdfTrial1.pdf");
		
		byte [] data = JasperExportManager.exportReportToPdf(report);
		
		HttpHeaders headers = new HttpHeaders();
		headers.set(HttpHeaders.CONTENT_DISPOSITION, "inline;filename=notes.pdf");
		
		//		return "pdf generatee999999999999999999999";
	
		return ResponseEntity.ok().headers(headers).contentType(MediaType.APPLICATION_PDF).body(data);
	}
}
