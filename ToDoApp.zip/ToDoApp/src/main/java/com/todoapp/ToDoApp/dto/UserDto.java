package com.todoapp.ToDoApp.dto;

import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.NotBlank;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;
import org.springframework.lang.NonNull;
import org.springframework.lang.Nullable;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "UserDto")
@Getter
@Setter
@ToString
@JsonIgnoreProperties({"hibernateLazyInitializer","handler"})
public class UserDto {

	@Id 
	@GeneratedValue
	private int userId;
	
	@Column(name="USER_NAME")
	private String userName;
	
	@NotBlank(message = "E-Mail required")
	@Column(name="USER_EMAIL",unique = true)
	private String userGmail;
	
	@Column(name="USER_CONTACT", length = 10,unique = true)
	private String userContact;
	
	@Column(name="USER_PASSWORD")
	private String userPassword;
	
	@OneToMany(cascade = CascadeType.ALL, mappedBy = "userId", fetch = FetchType.EAGER)
	private List<TaskDto> task;
	
	@Column(name="MY_POINTS")
	private int myPoints;
	
	@Lob
	@Column(name = "USER_PIC")
	private Byte[] profilePic;
	
	@Column(name = "PIC_PATH")
	private String proImgPath;
	
	@Transient
	MultipartFile proImg;

	@Nullable
	@Column(name="USER_OTP")
	private int userOtp;
}
