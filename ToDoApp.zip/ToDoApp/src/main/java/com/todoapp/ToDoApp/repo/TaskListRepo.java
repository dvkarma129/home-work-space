package com.todoapp.ToDoApp.repo;

import java.util.ArrayList;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.todoapp.ToDoApp.dto.TaskDto;
import com.todoapp.ToDoApp.dto.UserDto;

@Repository
public interface TaskListRepo extends JpaRepository<TaskDto, Integer>{

	ArrayList<TaskDto> findAllByUserId(int userId);

	List<TaskDto> findAllByUser(int userId);

}
