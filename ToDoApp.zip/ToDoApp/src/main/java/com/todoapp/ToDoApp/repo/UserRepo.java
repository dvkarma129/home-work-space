package com.todoapp.ToDoApp.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.stereotype.Repository;

import com.todoapp.ToDoApp.dto.UserDto;

@Repository
@EnableJpaRepositories
public interface UserRepo extends JpaRepository<UserDto, Integer> {

	int countByUserGmailAndUserPassword(String userGmail, String userPassword);

	UserDto findByUserGmailAndUserPassword(String userGmail, String userPassword);

	int countByUserGmail(String userGmail);

	UserDto getByUserGmail(String userGmail);

	UserDto getByUserId(int userId);
}
