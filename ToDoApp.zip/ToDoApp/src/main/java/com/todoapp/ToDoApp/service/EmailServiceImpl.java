package com.todoapp.ToDoApp.service;

import java.util.Date;
import java.util.Random;

import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.mail.javamail.MimeMessagePreparator;
import org.springframework.stereotype.Service;


import com.todoapp.ToDoApp.dto.UserDto;
import com.todoapp.ToDoApp.repo.UserRepo;

@Service
public class EmailServiceImpl implements EmailService {
	
	private JavaMailSender javaMailSender;
	private final UserRepo urepo;
	
	@Value("${spring.mail.username}") private String sender;
	
	@Autowired
    public EmailServiceImpl (JavaMailSender javaMailSender, UserRepo urepo) {
        this.urepo = urepo;
		this.javaMailSender = javaMailSender;
    }

	@Override
	public String sendMail(UserDto udto) {
	    
	    StringBuilder sb = new StringBuilder();
	    sb.append("<html><head><style> body { font-family: 'Roboto', sans-serif; font-size: 48px; } </style><title> User registeration </title></head><p>Hello User, <br> <strong>" + udto.getUserName() + "</strong></p> <p> You have been successfully registered! </p> <p> You can find <b>your Details</b> just below this text. </p> <p> Contact: " + udto.getUserContact() + " </p> <p> G-Mail: " + udto.getUserGmail() + " </p> <p> Regards, <br/> <em>Team ToDo</em> </p> </body></html>\r\n");
	    try {
	    	
	    	MimeMessagePreparator preparator = new MimeMessagePreparator() {
	    		
	    		 @Override
	             public void prepare (MimeMessage mimeMessage) throws Exception {
	                MimeMessageHelper messageHelper = new MimeMessageHelper(mimeMessage, false, "utf-8");
	                 messageHelper.setTo(udto.getUserGmail());
	                 messageHelper.setSentDate(new Date());
	                 messageHelper.setFrom(sender);
	                 messageHelper.setSubject("Registration");
	                 messageHelper.setText("sucessfully regeisterd");
	                 mimeMessage.setContent(sb.toString(), "text/html");
	             }
	    	};
	    	
	    	this.javaMailSender.send(preparator);
	    	
	    } catch (Exception ex) {
	    	ex.printStackTrace();
	    }
	    return "User Successfully Register";
	}

	@Override
	public int sendOtp(UserDto udto,int userId) {
		Random rnd = new Random();
	    int otp = rnd.nextInt(999999);
	    System.out.println("otp--->" + otp);
	    
	    StringBuilder sb = new StringBuilder();
	    sb.append("<html><head><title> login verifiaction </title></head><body><div style=\"font-family: Helvetica,Arial,sans-serif;min-width:1000px;overflow:auto;line-height:2\"> <div style=\"margin:50px auto;width:70%;padding:20px 0\"><p style=\"font-size:1.1em\">Hi,</p> <p>Use the following OTP to complete your Sign-In</p> <h2 style=\"background: #36b5d4;margin: 0 auto;width: max-content;padding: 0 10px;color: #fff;border-radius: 4px;\"> " + otp + "</h2> <p style=\"font-size:0.9em;\">Regards,<br />Team ToDo</p> </div> </div></body></html>\r\n");
	    
	    try {
	    	
	    	MimeMessagePreparator preparator = new MimeMessagePreparator() {
	    		
	    		 @Override
	             public void prepare (MimeMessage mimeMessage) throws Exception {
	                MimeMessageHelper messageHelper = new MimeMessageHelper(mimeMessage, false, "utf-8");
	                 messageHelper.setTo(udto.getUserGmail());
	                 messageHelper.setSentDate(new Date());
	                 messageHelper.setFrom(sender);
	                 messageHelper.setSubject("Login verification");
	                 messageHelper.setText("Use 6 digit code to login");
	                 mimeMessage.setContent(sb.toString(), "text/html");
	             }
	    		 
	    	};
	 	    udto.setUserOtp(otp);
	    	urepo.save(udto);
	    	this.javaMailSender.send(preparator);
	    	
	    } catch (Exception ex) {
	    	ex.printStackTrace();
	    }
		return otp;
	}
}
