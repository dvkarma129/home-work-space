package com.todoapp.ToDoApp.service;

import com.todoapp.ToDoApp.dto.UserDto;

public interface EmailService {

	String sendMail(UserDto udto);

	int sendOtp(UserDto udto, int userId);

}
