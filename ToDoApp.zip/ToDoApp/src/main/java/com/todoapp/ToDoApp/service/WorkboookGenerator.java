package com.todoapp.ToDoApp.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.todoapp.ToDoApp.dto.TaskDto;
import com.todoapp.ToDoApp.repo.TaskListRepo;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class WorkboookGenerator {

	private final TaskListRepo tRepo;

	public void generateWorkbook() throws IOException {
		// TODO Auto-generated method stub
		Workbook wb = new HSSFWorkbook();
		OutputStream fileout = new FileOutputStream("E:\\ToDoApp\\downloads\\task.xls");
		wb.write(fileout);
	}

	public void downloadData(int userId) throws IOException {
//		String filename ="E:\\ToDoApp\\downloads\\task.xls";
		String filename = "C:\\Users\\jituu\\Documents\\workspace-spring-tool-suite-4-4.17.2.RELEASE\\ToDoApp\\downloads\\task.xls";
		HSSFWorkbook wb = new HSSFWorkbook();
		HSSFSheet sheet = wb.createSheet("Task data");
		HSSFRow rowhead = sheet.createRow((short) 0);

		rowhead.createCell(0).setCellValue("taskId");
		rowhead.createCell(1).setCellValue("topic");
		rowhead.createCell(2).setCellValue("description");
		rowhead.createCell(3).setCellValue("createdDate");
		rowhead.createCell(4).setCellValue("completedDate");
		rowhead.createCell(5).setCellValue("status");

		List<TaskDto> dto = tRepo.findAllByUserId(userId);
//		List<TaskDto> dto = tRepo.findAll();
		int i = 1;
		for (TaskDto taskDto : dto) {
			HSSFRow row = sheet.createRow((short) i++);
			row.createCell(0).setCellValue(taskDto.getTaskId());
			row.createCell(1).setCellValue(taskDto.getTopic());
			row.createCell(2).setCellValue(taskDto.getDescription());
			row.createCell(3).setCellValue(taskDto.getCreatedDate());
			row.createCell(4).setCellValue(taskDto.getCompletedDate());
			row.createCell(5).setCellValue(taskDto.getStatus());
		}
		FileOutputStream fileout = new FileOutputStream(filename);
		wb.write(fileout);
		fileout.close();
		wb.close();
	}

	public void insertWorkbook() {

		try {
			File file = new File(
					"C:\\\\Users\\\\jituu\\\\Documents\\\\workspace-spring-tool-suite-4-4.17.2.RELEASE\\\\ToDoApp\\\\downloads\\\\tasks.xls");
			FileInputStream fis = new FileInputStream(file);
			HSSFWorkbook wb = new HSSFWorkbook(fis);
			HSSFSheet sheet = wb.getSheetAt(0);
			Iterator<Row> itr = sheet.iterator();

			itr.next(); // skip the header row
			while (itr.hasNext()) {
				Row nextRow = itr.next();
				Iterator<Cell> cellIterator = nextRow.cellIterator();

				TaskDto dto = new TaskDto();
				while (cellIterator.hasNext()) {

					Cell nextCell = cellIterator.next();
					int columnIndex = nextCell.getColumnIndex();
					switch (columnIndex) {
					case 0:
						dto.setTopic(nextCell.getStringCellValue());
						break;
					case 1:
						dto.setDescription(nextCell.getStringCellValue());
						break;
					case 2:
						dto.setStatus(nextCell.getStringCellValue());
						break;
					case 3:
						dto.setUserId((int) nextCell.getNumericCellValue());
						break;
					}
				}
				tRepo.save(dto);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void insertFile(MultipartFile file, int userId) {
		try {
			HSSFWorkbook wb = new HSSFWorkbook(file.getInputStream());
			HSSFSheet sheet = wb.getSheetAt(0);
			Iterator<Row> itr = sheet.iterator();
			itr.next(); // skip the header row
			while (itr.hasNext()) {
				Row nextRow = itr.next();
				Iterator<Cell> cellIterator = nextRow.cellIterator();
				TaskDto dto = new TaskDto();
				while (cellIterator.hasNext()) {
					Cell nextCell = cellIterator.next();
					int columnIndex = nextCell.getColumnIndex();
					switch (columnIndex) {
					case 0:
						dto.setTopic(nextCell.getStringCellValue());
						break;
					case 1:
						dto.setDescription(nextCell.getStringCellValue());
						break;
					case 2:
						dto.setStatus(nextCell.getStringCellValue());
						break;
					}
					dto.setUserId(userId);
				}
				System.out.println("inserted dto data-------->" + dto);
				tRepo.save(dto);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}