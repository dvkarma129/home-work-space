package com.todoapp.ToDoApp.dto;

import java.sql.Date;
import java.sql.Time;
import java.sql.Timestamp;
import java.time.LocalDateTime;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.print.attribute.standard.DateTimeAtCreation;
import javax.validation.constraints.NotBlank;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "TodoList")
@Getter
@Setter
@ToString
@JsonIgnoreProperties({ "hibernateLazyInitializer", "handler" })
public class TaskDto {

	@Id
	@GeneratedValue//(strategy = GenerationType.AUTO)
	private int taskId;

	@NotBlank(message = "Description required")
	@Column(name = "TASK_TOPIC")
	private String topic;
	
	@Column(name = "TASK_DESCRIPTION", length = 200)
	private String description;

	@Column(name = "TASK_STATUS")
	private String status;

	@CreationTimestamp
	@Column(name = "TASK_CREATED_DATE")
	private Date createdDate;

	@Column(name = "TASK_COMPLETED_DATE")
	private Date completedDate;

	@Column(name = "TASK_COMPLETED_ON_DATE")
	@UpdateTimestamp
	private Date completedOnDate;
	
	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinColumn(name = "usId")
    private UserDto user;
	
	@Column(nullable = false)
	private int userId;
}
